//Simple Hello World Program 
#include<stdio.h>
    int main() { 
    printf("Hello World , Created Bitbake recipe successfully\n"); 
    return 0;
}
